pip install selenium
pip install beautifulsoup

list of drivers
https://pypi.org/project/selenium/

download and put into path Chrome Driver for Selenium
https://chromedriver.storage.googleapis.com/index.html?path=78.0.3904.105/

